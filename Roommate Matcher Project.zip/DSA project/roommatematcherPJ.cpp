// roommate_matcher.cpp
// Compile: g++ -std=c++17 roommate_matcher.cpp -o roommate
// Run: ./roommate
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <algorithm>
#include <unordered_set>
#include <limits>
#include <iomanip>
#include <cmath>
#include <cctype>
using namespace std;

struct Student {
    int id;
    string name;
    char gender; // 'M' or 'F'
    int age;
    string room_pref;
    bool smoking;
    int cleanliness; // 1-5
    string study_habit; // early/mid/late
    int sleep_time; // 0-23
    int wake_time;  // 0-23
    vector<string> hobbies;
};

const string DB_FILENAME = "students_db.txt";

// ---------- Utilities ----------
string trim(const string &s) {
    size_t i = 0, j = s.size();
    while (i < j && isspace((unsigned char)s[i])) i++;
    while (j > i && isspace((unsigned char)s[j-1])) j--;
    return s.substr(i, j - i);
}

vector<string> split(const string &s, char delim) {
    vector<string> out;
    string cur;
    for (char c : s) {
        if (c == delim) { out.push_back(cur); cur.clear(); }
        else cur.push_back(c);
    }
    out.push_back(cur);
    for (auto &x : out) x = trim(x);
    return out;
}

string toLower(string s) {
    transform(s.begin(), s.end(), s.begin(), ::tolower);
    return s;
}

int next_id(const vector<Student>& v) {
    int mx = 0;
    for (auto &st : v) if (st.id > mx) mx = st.id;
    return mx + 1;
}

// ---------- File IO ----------
vector<Student> load_db() {
    vector<Student> students;
    ifstream fin(DB_FILENAME);
    if (!fin.is_open()) {
        // file not present -> create empty file
        ofstream fout(DB_FILENAME);
        fout.close();
        return students;
    }
    string line;
    while (getline(fin, line)) {
        if (line.empty()) continue;
        // id,name,gender,age,room_pref,smoking,cleanliness,study_habit,sleep_time,wake_time,hobbies
        auto cols = split(line, ',');
        if (cols.size() < 11) continue; // skip bad lines
        Student s;
        try {
            s.id = stoi(cols[0]);
            s.name = cols[1];
            s.gender = cols[2].empty() ? 'M' : cols[2][0];
            s.age = stoi(cols[3]);
            s.room_pref = cols[4];
            string sm = cols[5];
            s.smoking = (toLower(sm)=="1" || toLower(sm)=="true" || toLower(sm)=="yes");
            s.cleanliness = stoi(cols[6]);
            s.study_habit = cols[7];
            s.sleep_time = stoi(cols[8]);
            s.wake_time = stoi(cols[9]);
            s.hobbies = split(cols[10], ';');
        } catch (...) { continue; }
        students.push_back(s);
    }
    fin.close();
    return students;
}

void save_db(const vector<Student>& students) {
    ofstream fout(DB_FILENAME, ios::trunc);
    // write one student per line CSV-style
    for (auto &s : students) {
        string hb;
        for (size_t i = 0; i < s.hobbies.size(); ++i) {
            hb += s.hobbies[i];
            if (i + 1 < s.hobbies.size()) hb += ';';
        }
        fout << s.id << "," << s.name << "," << s.gender << "," << s.age << ","
             << s.room_pref << "," << (s.smoking ? "1" : "0") << "," << s.cleanliness << ","
             << s.study_habit << "," << s.sleep_time << "," << s.wake_time << "," << hb << "\n";
    }
    fout.close();
}

// ---------- Matching logic ----------
int hourDiff(int a, int b) {
    int d = abs(a - b);
    return min(d, 24 - d);
}
double compute_score(const Student &x, const Student &y) {
    if (tolower(static_cast<unsigned char>(x.gender)) != tolower(static_cast<unsigned char>(y.gender))) return -1e9; // disallow different genders
    double score = 0.0;
    const double w_smoking = 20;
    const double w_clean = 15;
    const double w_study = 12;
    const double w_sleep = 18;
    const double w_hobby = 10;
    const double w_age = 5;
    const double w_room_pref = 8;

    if (x.smoking == y.smoking) score += w_smoking;
    int cd = abs(x.cleanliness - y.cleanliness);
    score += w_clean * (1.0 - (double)cd / 4.0);
    if (toLower(x.study_habit) == toLower(y.study_habit)) score += w_study;
    int sd = hourDiff(x.sleep_time, y.sleep_time);
    score += w_sleep * (1.0 - (double)sd / 12.0);

    unordered_set<string> hh;
    for (auto &h : x.hobbies) hh.insert(toLower(trim(h)));
    int common = 0;
    for (auto &h : y.hobbies) if (hh.count(toLower(trim(h)))) common++;
    score += w_hobby * (min(5, common) / 5.0);

    int ad = abs(x.age - y.age);
    score += w_age * (1.0 - min(ad,10)/10.0);
    if (toLower(x.room_pref) == toLower(y.room_pref)) score += w_room_pref;

    return score;
}

// ---------- Find / CRUD ----------
int find_index_by_name(const vector<Student>& students, const string &name) {
    string q = toLower(trim(name));
    for (int i = 0; i < (int)students.size(); ++i) {
        if (toLower(students[i].name) == q) return i;
    }
    return -1;
}

void print_student(const Student &s) {
    cout << "ID:" << s.id << " | " << s.name << " | " << s.gender << " | age " << s.age << "\n";
    cout << "RoomPref: " << s.room_pref << " | Smoking: " << (s.smoking ? "Yes" : "No") << " | Cleanliness: " << s.cleanliness << "\n";
    cout << "Study: " << s.study_habit << " | Sleep: " << s.sleep_time << " | Wake: " << s.wake_time << "\n";
    cout << "Hobbies: ";
    for (size_t i = 0; i < s.hobbies.size(); ++i) {
        cout << s.hobbies[i];
        if (i + 1 < s.hobbies.size()) cout << ", ";
    }
    cout << "\n-----------------------------------\n";
}

void add_student(vector<Student>& students) {
    Student s;
    s.id = next_id(students);
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cout << "Enter full name: "; getline(cin, s.name);
    string g;
    cout << "Gender (M/F): "; getline(cin, g); s.gender = (g.empty()? 'M' : g[0]);
    cout << "Age: "; string tmp; getline(cin, tmp); s.age = stoi(tmp);
    cout << "Room preference (double/single/quiet/...): "; getline(cin, s.room_pref);
    cout << "Smoking (1=Yes, 0=No): "; getline(cin, tmp); s.smoking = (toLower(tmp)=="1" || toLower(tmp)=="yes" || toLower(tmp)=="true");
    cout << "Cleanliness (1-5): "; getline(cin, tmp); s.cleanliness = stoi(tmp);
    cout << "Study habit (early/mid/late): "; getline(cin, s.study_habit);
    cout << "Sleep time (0-23): "; getline(cin, tmp); s.sleep_time = stoi(tmp);
    cout << "Wake time (0-23): "; getline(cin, tmp); s.wake_time = stoi(tmp);
    cout << "Enter hobbies separated by ';' (e.g. music;cricket): "; getline(cin, tmp);
    s.hobbies = split(tmp, ';');

    students.push_back(s);
    save_db(students);
    cout << "\n✅ Student added and saved (ID: " << s.id << ")\n";
}

void edit_student(vector<Student>& students) {
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cout << "Enter exact name to edit: ";
    string name; getline(cin, name);
    int idx = find_index_by_name(students, name);
    if (idx == -1) { cout << "❌ No record found for that name.\n"; return; }
    cout << "\nCurrent record:\n"; print_student(students[idx]);
    cout << "Enter new values (leave blank to keep current)\n";

    string tmp;
    cout << "Full name [" << students[idx].name << "]: "; getline(cin, tmp); if (!tmp.empty()) students[idx].name = tmp;
    cout << "Gender [" << students[idx].gender << "]: "; getline(cin, tmp); if (!tmp.empty()) students[idx].gender = tmp[0];
    cout << "Age [" << students[idx].age << "]: "; getline(cin, tmp); if (!tmp.empty()) students[idx].age = stoi(tmp);
    cout << "Room preference [" << students[idx].room_pref << "]: "; getline(cin, tmp); if (!tmp.empty()) students[idx].room_pref = tmp;
    cout << "Smoking (1/0) [" << (students[idx].smoking? "1":"0") << "]: "; getline(cin, tmp); if (!tmp.empty()) students[idx].smoking = (toLower(tmp)=="1");
    cout << "Cleanliness (1-5) [" << students[idx].cleanliness << "]: "; getline(cin, tmp); if (!tmp.empty()) students[idx].cleanliness = stoi(tmp);
    cout << "Study habit [" << students[idx].study_habit << "]: "; getline(cin, tmp); if (!tmp.empty()) students[idx].study_habit = tmp;
    cout << "Sleep time [" << students[idx].sleep_time << "]: "; getline(cin, tmp); if (!tmp.empty()) students[idx].sleep_time = stoi(tmp);
    cout << "Wake time [" << students[idx].wake_time << "]: "; getline(cin, tmp); if (!tmp.empty()) students[idx].wake_time = stoi(tmp);
    cout << "Hobbies (sep ;) ["; for (size_t i=0;i<students[idx].hobbies.size();++i){ if(i) cout<<";"; cout<<students[idx].hobbies[i]; } cout<<"]:\n";
    getline(cin, tmp); if (!tmp.empty()) students[idx].hobbies = split(tmp, ';');

    save_db(students);
    cout << "\n✅ Student record updated and saved.\n";
}

void delete_student(vector<Student>& students) {
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cout << "Enter exact name to delete: ";
    string name; getline(cin, name);
    int idx = find_index_by_name(students, name);
    if (idx == -1) { cout << "❌ No record found for that name.\n"; return; }
    cout << "Deleting record:\n"; print_student(students[idx]);
    cout << "Are you sure? (y/n): ";
    char c; cin >> c;
    if (c == 'y' || c == 'Y') {
        students.erase(students.begin() + idx);
        save_db(students);
        cout << "✅ Deleted and changes saved.\n";
    } else {
        cout << "Cancelled.\n";
    }
}

void show_all(const vector<Student>& students) {
    if (students.empty()) { cout << "No students in database.\n"; return; }
    cout << "\n--- All Students (" << students.size() << ") ---\n";
    for (auto &s : students) print_student(s);
}

void find_roommate_by_name(const vector<Student>& students) {
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cout << "Enter your full name: ";
    string name; getline(cin, name);
    int idx = find_index_by_name(students, name);
    if (idx == -1) { cout << "❌ No student record found with this name.\n"; return; }

    vector<pair<double,int>> scores;
    for (int i = 0; i < (int)students.size(); ++i) {
        if (i == idx) continue;
        double sc = compute_score(students[idx], students[i]);
        if (sc > -1e8) scores.push_back({sc, i});
    }
    if (scores.empty()) { cout << "No compatible candidates found.\n"; return; }
    sort(scores.rbegin(), scores.rend()); // descending
    cout << "\nTop 3 roommate suggestions for " << students[idx].name << ":\n";
    int limit = min(3, (int)scores.size());
    for (int k = 0; k < limit; ++k) {
        int j = scores[k].second;
        cout << "→ " << students[j].name << " (Score: " << fixed << setprecision(2) << scores[k].first << ")\n";
        print_student(students[j]);
    }
}

// ---------- Main ----------
int main() {
    vector<Student> students = load_db();
    // if db empty, preload few sample records
    if (students.empty()) {
        students.push_back({1,"Ali Khan",'M',20,"double",false,4,"early",23,6,{"reading","cricket","music"}});
        students.push_back({2,"Omar Saeed",'M',21,"double",false,5,"early",22,6,{"music","football"}});
        students.push_back({3,"Usman Ali",'M',19,"double",true,2,"late",3,10,{"gaming","movies"}});
        save_db(students);
    }

    while (true) {
        cout << "\n===== SMART ROOMMATE MATCHER =====\n";
        cout << "1. Add new student\n";
        cout << "2. Find roommate by name (top-3)\n";
        cout << "3. Edit student\n";
        cout << "4. Delete student\n";
        cout << "5. Show all students\n";
        cout << "6. Exit\n";
        cout << "Choose: ";
        int ch; if (!(cin >> ch)) { cin.clear(); cin.ignore(numeric_limits<streamsize>::max(), '\n'); continue; }
        switch (ch) {
            case 1: add_student(students); break;
            case 2: find_roommate_by_name(students); break;
            case 3: edit_student(students); break;
            case 4: delete_student(students); break;
            case 5: show_all(students); break;
            case 6: cout << "Exiting. Bye!\n"; return 0;
            default: cout << "Invalid choice.\n";
        }
    }
    return 0;
}